from django.urls import path
from .views import SignupView, LoginView, VerifyOTPView
from .views import trigger_test_otp

urlpatterns = [
    path('signup/', SignupView.as_view()),
    path('login/', LoginView.as_view()),
    path('verify-otp/', VerifyOTPView.as_view()),
    path('test-otp/', trigger_test_otp),  # optional
]
